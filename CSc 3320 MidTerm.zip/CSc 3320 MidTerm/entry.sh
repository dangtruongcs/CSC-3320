#!/bin/bash
echo -n "Enter a name: " 
read name
echo -n "Enter the address: "
read address
echo -n "Enter the Phone number: "
read phone
echo "$name: $address: $phone: " >>book.txt 
