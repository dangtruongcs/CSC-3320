#!/bin/bash
echo -n "please enter a name to find: "
read q
echo "Name: Address: Phone number: "
grep -i $q book.txt
