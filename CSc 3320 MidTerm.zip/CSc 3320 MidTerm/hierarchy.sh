#!/bin/bash
echo "enter number of days"
read n
find /home/dtruong17 -atime +$n -type f | zip compress -@
