#!/bin/sh
echo -n "Enter a name you want to delete: "
read name
sed -e "/$name/d" book.txt
