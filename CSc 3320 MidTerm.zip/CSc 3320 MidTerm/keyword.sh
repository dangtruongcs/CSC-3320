#!/bin/bash
echo "Please enter a keyword: "
read n
grep -o -i $n myexamfile.txt | wc -l
