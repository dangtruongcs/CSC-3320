#include <stdio.h>
int check_factorial(int gen){
if(gen==0) return 1;
return gen*check_factorial(gen-1);
}
int main()
{
printf("%d\n",check_factorial(5));
return 0;
}